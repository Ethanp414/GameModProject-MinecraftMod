package dibs.bossfight;

import dibs.bossfight.clients.BossMusicController;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod; // <-- THIS import fixes your error
import net.neoforged.neoforge.client.event.ClientTickEvent;

@Mod.EventBusSubscriber(
        modid = DePaulDibsBossFight.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.GAME,
        value = Dist.CLIENT
)
public final class ClientTicks {
    private ClientTicks() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        BossMusicController.clientTick();
    }
}
