package dibs.bossfight.clients;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;

import Entity.custom.DibsEntity;       // your entity package
import dibs.bossfight.ModSounds;      // your registered sounds

public final class BossMusicController {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final RandomSource RNG = RandomSource.create();

    // --- configurable timings (adjust to your audio lengths) ---
    // Length of bossfight1 in ticks (20 ticks = 1 second).
    private static final int INTRO_TICKS = 8 * 20;  // <-- change to your real intro length
    // Cooldown to avoid re-start spam when target flickers:
    private static final int RECHECK_COOLDOWN_TICKS = 10;

    // --- state ---
    private static boolean inBattle = false;     // true when any nearby Dibs is aggro (target != null)
    private static boolean introPlaying = false; // true while intro is “active”
    private static boolean loopPlaying = false;  // true while loop has been started
    private static boolean defeatPlayed = false; // true after we’ve played defeat

    private static int introTicksLeft = 0;
    private static int recheckCooldown = 0;

    private BossMusicController() {}

    // Call this on client tick (you already have a ClientTicks that calls BossMusicController.clientTick())
    public static void clientTick() {
        if (MC.level == null || MC.player == null) return;

        // Find a nearby Dibs and see if it's actually in battle (aggroed).
        DibsEntity boss = findNearestAggroDibs(MC.player, 64.0);
        boolean hasAggroBoss = boss != null;

        if (recheckCooldown > 0) recheckCooldown--;

        // Entering battle
        if (!inBattle && hasAggroBoss) {
            inBattle = true;
            defeatPlayed = false;
            startIntro();        // play bossfight1 once
            stopVanillaMusic();  // drop vanilla BGM to emphasize fight
        }

        // While in intro, count down and start loop after
        if (inBattle && introPlaying) {
            if (introTicksLeft > 0) {
                introTicksLeft--;
            }
            if (introTicksLeft == 0) {
                introPlaying = false;
                startLoop(); // bossfight2 starts looping
            }
        }

        // Exiting battle (boss no longer aggro on anyone, or dead)
        if (inBattle && !hasAggroBoss && recheckCooldown == 0) {
            inBattle = false;
            stopLoop();
            playDefeat();
            recheckCooldown = RECHECK_COOLDOWN_TICKS;
        }
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private static DibsEntity findNearestAggroDibs(Player player, double radius) {
        // Only treat as "battle" if the mob reports aggro
        return player.level().getEntitiesOfClass(
                DibsEntity.class,
                player.getBoundingBox().inflate(radius)
        ).stream().filter(DibsEntity::isAggro).findFirst().orElse(null);
    }

    private static void startIntro() {
        introPlaying = true;
        loopPlaying = false;
        introTicksLeft = INTRO_TICKS;

        // Start bossfight1 once
        // Ensure your sound events were registered as MUSIC category in ModSounds
        MC.getSoundManager().play(SimpleSoundInstance.forMusic(ModSounds.BOSSFIGHT1.get(), 1.0F));
    }

    private static void startLoop() {
        if (loopPlaying) return;
        loopPlaying = true;

        // Start bossfight2 (your sound json should be stream:true; if it doesn't loop,
        // just make the ogg long, or retrigger after duration if you want)
        MC.getSoundManager().play(SimpleSoundInstance.forMusic(ModSounds.BOSSFIGHT2.get(), 1.0F));
    }

    private static void stopLoop() {
        if (!loopPlaying) return;
        loopPlaying = false;
        MC.getSoundManager().stop(ModSounds.BOSSFIGHT2.getId(), SoundSource.MUSIC);
    }

    private static void playDefeat() {
        if (defeatPlayed) return;
        defeatPlayed = true;

        // Quick fade idea: stop the loop first (already done), then play defeat cue
        MC.getSoundManager().play(SimpleSoundInstance.forMusic(ModSounds.BOSSDEFEAT1.get(), 1.0F));
    }

    private static void stopVanillaMusic() {
        // This politely stops the vanilla background track once, but doesn't block future vanilla music forever.
        MC.getMusicManager().stopPlaying();
    }
}
