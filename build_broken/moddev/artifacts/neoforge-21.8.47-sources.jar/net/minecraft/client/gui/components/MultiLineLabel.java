package net.minecraft.client.gui.components;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface MultiLineLabel {
    MultiLineLabel EMPTY = new MultiLineLabel() {
        @Override
        public void renderCentered(GuiGraphics p_283287_, int p_94383_, int p_94384_) {
        }

        @Override
        public void renderCentered(GuiGraphics p_283208_, int p_210825_, int p_210826_, int p_210827_, int p_210828_) {
        }

        @Override
        public void renderLeftAligned(GuiGraphics p_283077_, int p_94379_, int p_94380_, int p_282157_, int p_282742_) {
        }

        @Override
        public int renderLeftAlignedNoShadow(GuiGraphics p_283645_, int p_94389_, int p_94390_, int p_94391_, int p_94392_) {
            return p_94390_;
        }

        @Nullable
        @Override
        public Style getStyleAtCentered(int p_428496_, int p_428494_, int p_428214_, double p_428350_, double p_428386_) {
            return null;
        }

        @Nullable
        @Override
        public Style getStyleAtLeftAligned(int p_428315_, int p_428452_, int p_428228_, double p_428428_, double p_428510_) {
            return null;
        }

        @Override
        public int getLineCount() {
            return 0;
        }

        @Override
        public int getWidth() {
            return 0;
        }
    };

    static MultiLineLabel create(Font font, Component... components) {
        return create(font, Integer.MAX_VALUE, Integer.MAX_VALUE, components);
    }

    static MultiLineLabel create(Font font, int maxWidth, Component... components) {
        return create(font, maxWidth, Integer.MAX_VALUE, components);
    }

    static MultiLineLabel create(Font font, Component component, int maxWidth) {
        return create(font, maxWidth, Integer.MAX_VALUE, component);
    }

    static MultiLineLabel create(final Font font, final int maxWidth, final int maxRows, final Component... components) {
        return components.length == 0
            ? EMPTY
            : new MultiLineLabel() {
                @Nullable
                private List<MultiLineLabel.TextAndWidth> cachedTextAndWidth;
                @Nullable
                private Language splitWithLanguage;

                @Override
                public void renderCentered(GuiGraphics p_281603_, int p_281267_, int p_281819_) {
                    this.renderCentered(p_281603_, p_281267_, p_281819_, 9, -1);
                }

                @Override
                public void renderCentered(GuiGraphics p_283492_, int p_283184_, int p_282078_, int p_352944_, int p_352919_) {
                    int i = p_282078_;

                    for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.getSplitMessage()) {
                        p_283492_.drawString(font, multilinelabel$textandwidth.text, p_283184_ - multilinelabel$textandwidth.width / 2, i, p_352919_);
                        i += p_352944_;
                    }
                }

                @Override
                public void renderLeftAligned(GuiGraphics p_282318_, int p_283665_, int p_283416_, int p_281919_, int p_281686_) {
                    int i = p_283416_;

                    for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.getSplitMessage()) {
                        p_282318_.drawString(font, multilinelabel$textandwidth.text, p_283665_, i, p_281686_);
                        i += p_281919_;
                    }
                }

                @Override
                public int renderLeftAlignedNoShadow(GuiGraphics p_281782_, int p_282841_, int p_283554_, int p_282768_, int p_283499_) {
                    int i = p_283554_;

                    for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.getSplitMessage()) {
                        p_281782_.drawString(font, multilinelabel$textandwidth.text, p_282841_, i, p_283499_, false);
                        i += p_282768_;
                    }

                    return i;
                }

                @Nullable
                @Override
                public Style getStyleAtCentered(int p_428222_, int p_428223_, int p_428447_, double p_428232_, double p_428416_) {
                    List<MultiLineLabel.TextAndWidth> list = this.getSplitMessage();
                    int i = Mth.floor((p_428416_ - p_428223_) / p_428447_);
                    if (i >= 0 && i < list.size()) {
                        MultiLineLabel.TextAndWidth multilinelabel$textandwidth = list.get(i);
                        int j = p_428222_ - multilinelabel$textandwidth.width / 2;
                        if (p_428232_ < j) {
                            return null;
                        } else {
                            int k = Mth.floor(p_428232_ - j);
                            return font.getSplitter().componentStyleAtWidth(multilinelabel$textandwidth.text, k);
                        }
                    } else {
                        return null;
                    }
                }

                @Nullable
                @Override
                public Style getStyleAtLeftAligned(int p_428507_, int p_428486_, int p_428523_, double p_428529_, double p_428439_) {
                    if (p_428529_ < p_428507_) {
                        return null;
                    } else {
                        List<MultiLineLabel.TextAndWidth> list = this.getSplitMessage();
                        int i = Mth.floor((p_428439_ - p_428486_) / p_428523_);
                        if (i >= 0 && i < list.size()) {
                            MultiLineLabel.TextAndWidth multilinelabel$textandwidth = list.get(i);
                            int j = Mth.floor(p_428529_ - p_428507_);
                            return font.getSplitter().componentStyleAtWidth(multilinelabel$textandwidth.text, j);
                        } else {
                            return null;
                        }
                    }
                }

                private List<MultiLineLabel.TextAndWidth> getSplitMessage() {
                    Language language = Language.getInstance();
                    if (this.cachedTextAndWidth != null && language == this.splitWithLanguage) {
                        return this.cachedTextAndWidth;
                    } else {
                        this.splitWithLanguage = language;
                        List<FormattedText> list = new ArrayList<>();

                        for (Component component : components) {
                            list.addAll(font.splitIgnoringLanguage(component, maxWidth));
                        }

                        this.cachedTextAndWidth = new ArrayList<>();
                        int i = Math.min(list.size(), maxRows);
                        List<FormattedText> list1 = list.subList(0, i);

                        for (int j = 0; j < list1.size(); j++) {
                            FormattedText formattedtext2 = list1.get(j);
                            FormattedCharSequence formattedcharsequence = Language.getInstance().getVisualOrder(formattedtext2);
                            if (j == list1.size() - 1 && i == maxRows && i != list.size()) {
                                FormattedText formattedtext = font.substrByWidth(
                                    formattedtext2, font.width(formattedtext2) - font.width(CommonComponents.ELLIPSIS)
                                );
                                FormattedText formattedtext1 = FormattedText.composite(formattedtext, CommonComponents.ELLIPSIS);
                                this.cachedTextAndWidth
                                    .add(new MultiLineLabel.TextAndWidth(Language.getInstance().getVisualOrder(formattedtext1), font.width(formattedtext1)));
                            } else {
                                this.cachedTextAndWidth.add(new MultiLineLabel.TextAndWidth(formattedcharsequence, font.width(formattedcharsequence)));
                            }
                        }

                        return this.cachedTextAndWidth;
                    }
                }

                @Override
                public int getLineCount() {
                    return this.getSplitMessage().size();
                }

                @Override
                public int getWidth() {
                    return Math.min(maxWidth, this.getSplitMessage().stream().mapToInt(MultiLineLabel.TextAndWidth::width).max().orElse(0));
                }
            };
    }

    void renderCentered(GuiGraphics guiGraphics, int x, int y);

    void renderCentered(GuiGraphics guiGraphics, int x, int y, int lineHeight, int color);

    void renderLeftAligned(GuiGraphics guiGraphics, int x, int y, int lineHeight, int color);

    int renderLeftAlignedNoShadow(GuiGraphics guiGraphics, int x, int y, int lineHeight, int color);

    @Nullable
    Style getStyleAtCentered(int x, int y, int height, double mouseX, double mouseY);

    @Nullable
    Style getStyleAtLeftAligned(int x, int y, int height, double mouseX, double mouseY);

    int getLineCount();

    int getWidth();

    @OnlyIn(Dist.CLIENT)
    public record TextAndWidth(FormattedCharSequence text, int width) {
    }
}
